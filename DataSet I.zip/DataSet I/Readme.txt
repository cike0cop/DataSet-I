This is data about traffic flow.
5 minutes time span.
